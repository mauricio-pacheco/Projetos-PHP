<?php require("verifica.php"); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml"><HEAD><TITLE>Lista Erechim</TITLE>
<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
<META 
content="Descri��o" 
name=description>
<META 
content="palavras, chave"><LINK media=screen href="home_arquivos/estrutura2009.css" 
type=text/css rel=stylesheet><LINK media=screen 
href="home_arquivos/interno2009.css" type=text/css rel=stylesheet><LINK 
media=screen href="home_arquivos/tooltip.css" type=text/css rel=stylesheet><LINK 
media=screen href="home_arquivos/wordcloud.css" type=text/css 
rel=stylesheet><LINK href="lupa.ico" 
rel="shortcut icon">
<LINK media=screen href="home_arquivos/MenuMatic.css" type=text/css 
charset=utf-8 rel=stylesheet><!--[if lt IE 7]>
    <link rel="stylesheet" href="home_arquivos/MenuMatic-ie6.css" type="text/css" media="screen" charset="utf-8" />
<![endif]-->
<LINK media=screen href="home_arquivos/Roar.css" type=text/css charset=utf-8 
rel=stylesheet>
<META content="MSHTML 6.00.6001.18000" name=GENERATOR></HEAD>
<BODY><!--Inicio do cabe�alho-->
<DIV id=sf_header>
<DIV id=sf_header_pai>
<DIV id=sf_header_logo><A class=logo_site 
title="Lista Erechim" 
href="index.php"></A></DIV>
<DIV id=sf_header_banner><SCRIPT src="carrega.js"></SCRIPT><SCRIPT language=javascript>
     carregaFlash('pub.swf','728','90'); // Depois s� descrever o caminho, largura, altura do SWF.
    </SCRIPT></DIV></DIV></DIV>
<DIV class=sf_header_menu>
  <table width="984" border="0" align="center">
    <tr>
      <td height="24" bordercolor="#A7D2EF" bgcolor="#C0D6E9" onClick="window.location='index.php';" onMouseOver="this.style.backgroundColor='#9ABDDC'; this.style.color='#252525'; this.style.cursor='pointer'" onMouseOut="this.style.backgroundColor='#C0D6E9'; this.style.color='#252525';" width="16%"><div align="center"><b><font color="#000000">P&aacute;gina Principal</font></b></div></td>
      <td height="24" bordercolor="#A7D2EF" bgcolor="#E6E6E6" onClick="window.location='numeros.php';" onMouseOver="this.style.backgroundColor='#9ABDDC'; this.style.color='#252525'; this.style.cursor='pointer'" onMouseOut="this.style.backgroundColor='#E6E6E6'; this.style.color='#252525';" width="16%"><div align="center"><b><font color="#000000">Cadastrar N�meros</font></b></div></td>
      <td height="24" bordercolor="#A7D2EF" bgcolor="#E6E6E6" onClick="window.location='admnumeros.php';" onMouseOver="this.style.backgroundColor='#9ABDDC'; this.style.color='#252525'; this.style.cursor='pointer'" onMouseOut="this.style.backgroundColor='#E6E6E6'; this.style.color='#252525';" width="16%"><div align="center"><b><font color="#000000">Administrar N�meros</font></b></div></td>
      <td height="24" bordercolor="#A7D2EF" bgcolor="#E6E6E6" onClick="window.location='banners.php';" onMouseOver="this.style.backgroundColor='#9ABDDC'; this.style.color='#252525'; this.style.cursor='pointer'" onMouseOut="this.style.backgroundColor='#E6E6E6'; this.style.color='#252525';" width="16%"><div align="center"><b><font color="#000000">Cadastrar Banner</font></b></div></td>
      <td height="24" bordercolor="#A7D2EF" bgcolor="#E6E6E6" onClick="window.location='admbanners.php';" onMouseOver="this.style.backgroundColor='#9ABDDC'; this.style.color='#252525'; this.style.cursor='pointer'" onMouseOut="this.style.backgroundColor='#E6E6E6'; this.style.color='#252525';" width="16%"><div align="center"><b><font color="#000000">Administrar Banners</font></b></div></td>
    </tr>
  </table>
</DIV>
<DIV id=sf_center>
<DIV id=sf_center_conteudo>
<DIV id=div_conteudo>
<DIV id=piso1>
 <table width="98%" border="0" align="center">
    <tr>
      <td><div align="center">CADASTRAR BANNER</div></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><?php
include "conexao.php";


$link = $_POST["link"];
$tipo = $_POST["tipo"];

if ($tipo == '1') {

$arquivo = isset($_FILES["foto"]) ? $_FILES["foto"] : FALSE;
$max_image_x = 728;
$max_image_y = 90;
$diretorio = 'banners/';
if($arquivo)
{
    $tamanho = getimagesize($arquivo["tmp_name"]);
    ini_set ("max_execution_time", 3600); // uma hora
    require_once "funcoesgalerias.php";
    $err = FALSE;
    if(is_uploaded_file($arquivo['tmp_name']))
    {
        if(verifica_image($arquivo))
        {
            $tamanho = getimagesize($arquivo["tmp_name"]);
            $dimensiona = verifica_dimensao_image($arquivo, $max_image_x, $max_image_y);
            if($dimensiona != '')
            {
                if($dimensiona == 'altura')
                {
                        $auxImage = $max_image_x;
                        $max_image_x = $max_image_y;
                        $max_image_y = $auxImage;
                }
            }
            else
            {
                $max_image_x = $tamanho[0];
                $max_image_y = $tamanho[1];
            }
            
            $nome_foto  = ('imagem_' . time() . '.' . verifica_extensao_image($arquivo));// nome &uacute;nico para foto
            $endFoto = $diretorio . $nome_foto;
            if(reduz_imagem($arquivo['tmp_name'], $max_image_x, $max_image_y, $endFoto))
            {
                $err = TRUE;
            }  
        }
    }
}

}

else

{


$arquivo = isset($_FILES["foto"]) ? $_FILES["foto"] : FALSE;
$max_image_x = 450;
$max_image_y = 140;
$diretorio = 'banners/';
if($arquivo)
{
    $tamanho = getimagesize($arquivo["tmp_name"]);
    ini_set ("max_execution_time", 3600); // uma hora
    require_once "funcoesgalerias.php";
    $err = FALSE;
    if(is_uploaded_file($arquivo['tmp_name']))
    {
        if(verifica_image($arquivo))
        {
            $tamanho = getimagesize($arquivo["tmp_name"]);
            $dimensiona = verifica_dimensao_image($arquivo, $max_image_x, $max_image_y);
            if($dimensiona != '')
            {
                if($dimensiona == 'altura')
                {
                        $auxImage = $max_image_x;
                        $max_image_x = $max_image_y;
                        $max_image_y = $auxImage;
                }
            }
            else
            {
                $max_image_x = $tamanho[0];
                $max_image_y = $tamanho[1];
            }
            
            $nome_foto  = ('imagem_' . time() . '.' . verifica_extensao_image($arquivo));// nome &uacute;nico para foto
            $endFoto = $diretorio . $nome_foto;
            if(reduz_imagem($arquivo['tmp_name'], $max_image_x, $max_image_y, $endFoto))
            {
                $err = TRUE;
            }  
        }
    }
}

}







$sql = "INSERT INTO banners (link, foto, tipo) VALUES ('$link', '$nome_foto', '$tipo')";
if(mysql_query($sql)) {
echo "<div align=center><br>O Banner foi cadastrado com sucesso!!</div>";
}else{
echo "<div align=center><br>N&atilde;o foi possivel efetuar o seu cadastro!</div>";
}
 
?></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
  </table>
</DIV>
<DIV class=pisos id=piso4><!-- TWITTER -->
  <DIV style="CLEAR: both"></DIV></DIV></DIV></DIV></DIV><!--fim do centro--><!--Inicio do rodape-->
<DIV style="CLEAR: both"></DIV>
<DIV id=sf_footer>
<DIV id=rodape_centro>
  <DIV class=assinatura><A class=scriptfacil title=" Casa da Web - Solu��es em Marketing Digital " 
style="FONT-SIZE: 10px; COLOR: #ffffff; TEXT-DECORATION: none" 
href="http://www.casadaweb.net" target=_blank>Desenvolvido por Casa da Web</A> 
  
</DIV></DIV></DIV><!--fim do rodape --><!-- Analytics -->
</BODY></HTML>
