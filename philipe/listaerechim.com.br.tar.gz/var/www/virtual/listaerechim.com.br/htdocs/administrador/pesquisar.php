<?php require("verifica.php"); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml"><HEAD><TITLE>Lista Erechim</TITLE>
<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
<META 
content="Descri��o" 
name=description>
<META 
content="palavras, chave"><LINK media=screen href="home_arquivos/estrutura2009.css" 
type=text/css rel=stylesheet><LINK media=screen 
href="home_arquivos/interno2009.css" type=text/css rel=stylesheet><LINK 
media=screen href="home_arquivos/tooltip.css" type=text/css rel=stylesheet><LINK 
media=screen href="home_arquivos/wordcloud.css" type=text/css 
rel=stylesheet><LINK href="lupa.ico" 
rel="shortcut icon">
<LINK media=screen href="home_arquivos/MenuMatic.css" type=text/css 
charset=utf-8 rel=stylesheet><!--[if lt IE 7]>
    <link rel="stylesheet" href="home_arquivos/MenuMatic-ie6.css" type="text/css" media="screen" charset="utf-8" />
<![endif]-->
<LINK media=screen href="home_arquivos/Roar.css" type=text/css charset=utf-8 
rel=stylesheet>
<META content="MSHTML 6.00.6001.18000" name=GENERATOR>
<style type="text/css">
<!--
.style2 {	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
}
-->
</style>
</HEAD>
<BODY><!--Inicio do cabe�alho-->
<DIV id=sf_header>
<DIV id=sf_header_pai>
<DIV id=sf_header_logo><A class=logo_site 
title="Lista Erechim" 
href="index.php"></A></DIV>
<DIV id=sf_header_banner><SCRIPT src="carrega.js"></SCRIPT><SCRIPT language=javascript>
     carregaFlash('pub.swf','728','90'); // Depois s� descrever o caminho, largura, altura do SWF.
    </SCRIPT></DIV></DIV></DIV>
<DIV class=sf_header_menu>
  <table width="984" border="0" align="center">
    <tr>
      <td height="24" bordercolor="#A7D2EF" bgcolor="#C0D6E9" onClick="window.location='index.php';" onMouseOver="this.style.backgroundColor='#9ABDDC'; this.style.color='#252525'; this.style.cursor='pointer'" onMouseOut="this.style.backgroundColor='#C0D6E9'; this.style.color='#252525';" width="16%"><div align="center"><b><font color="#000000">P&aacute;gina Principal</font></b></div></td>
      <td height="24" bordercolor="#A7D2EF" bgcolor="#E6E6E6" onClick="window.location='numeros.php';" onMouseOver="this.style.backgroundColor='#9ABDDC'; this.style.color='#252525'; this.style.cursor='pointer'" onMouseOut="this.style.backgroundColor='#E6E6E6'; this.style.color='#252525';" width="16%"><div align="center"><b><font color="#000000">Cadastrar N&uacute;meros</font></b></div></td>
      <td height="24" bordercolor="#A7D2EF" bgcolor="#E6E6E6" onClick="window.location='admnumeros.php';" onMouseOver="this.style.backgroundColor='#9ABDDC'; this.style.color='#252525'; this.style.cursor='pointer'" onMouseOut="this.style.backgroundColor='#E6E6E6'; this.style.color='#252525';" width="16%"><div align="center"><b><font color="#000000">Administrar N�meros</font></b></div></td>
      <td height="24" bordercolor="#A7D2EF" bgcolor="#E6E6E6" onClick="window.location='banners.php';" onMouseOver="this.style.backgroundColor='#9ABDDC'; this.style.color='#252525'; this.style.cursor='pointer'" onMouseOut="this.style.backgroundColor='#E6E6E6'; this.style.color='#252525';" width="16%"><div align="center"><b><font color="#000000">Cadastrar Banner</font></b></div></td>
      <td height="24" bordercolor="#A7D2EF" bgcolor="#E6E6E6" onClick="window.location='admbanners.php';" onMouseOver="this.style.backgroundColor='#9ABDDC'; this.style.color='#252525'; this.style.cursor='pointer'" onMouseOut="this.style.backgroundColor='#E6E6E6'; this.style.color='#252525';" width="16%"><div align="center"><b><font color="#000000">Administrar Banners</font></b></div></td>
    </tr>
  </table>
</DIV>
<DIV id=sf_center>
<DIV id=sf_center_conteudo>
<DIV id=div_conteudo>
<DIV id=piso1>
 <table width="98%" border="0" align="center">
    <tr>
      <td><div align="center">ADMINISTRAR N&Uacute;MEROS </div></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><div align="center"><a href="admusados.php" class="link_normal">ADMINISTRAR N&Uacute;MEROS DOS USU&Aacute;RIOS</a></div></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><script language=javascript>
function validar(cadastro) { 

if (document.busca.palavra.value=="") {
alert("O Campo Pesquisar n�o est� preenchido!")
busca.palavra.focus();
return false
}

}

</SCRIPT><form name="busca" action="pesquisar.php" method="post" onSubmit="return validar(this)"><table width="100%" border="0" align="center">
        <tr>
          <td width="71%" align="center">Digite o Nome do Cliente:
            <input name="palavra" type="text" id="palavra" size="100">
            <input type="submit" name="button" id="button" value="Buscar"></td>
          </tr>
      </table></form></td>
    </tr>
    <tr>
      <td><?php
								  
include "conexao.php";

if(!empty($HTTP_POST_VARS["palavra"])) {

        $palavra = str_replace(" ", "%", $HTTP_POST_VARS[palavra]);

        /* Altera os espa&ccedil;os adicionando no lugar o simbolo % */
        
      $qr = "SELECT * FROM telefones WHERE nome LIKE '%".$palavra."%'";
        
        // Executa a query no Banco de Dados
        $sql = mysql_query($qr);
        
        // Conta o total ded resultados encontrados
        $total = mysql_num_rows($sql);

        echo "<div align=\"center\"><font face='Verdana' size='2'>Sua busca retornou <font color\"#2C9955\">' $total ' </font> resultados.</font></div><br>";
			// Gera o Loop com os resultados
        while($r = mysql_fetch_array($sql)) {
		
 ?>
        <table width="80%" border="0" align="center">
          <tr>
            <td><span class="style2">
              <table width="100%" border="0" align="center">
                <tr>
                  <td width="5%"><?php
                     $branca = $r["status"];
					 $testeb = '0';
					 if ($branca == $testeb)
					 {
					  					  ?><img src="clientes.jpg"><?php } else { ?><a class="link_normal" href="liberarcliente.php?id=<?php echo $r["id"]; ?>"><img src="status.jpg" border="0" alt="LIBERAR USU�RIO?"></a><?php } ?></td>
                  <td width="70%"><font face="Verdana" size="2">&nbsp;<?php echo $r["nome"]; ?></font></td>
                  <td width="6%"><div align="center"><a class="link_normal" href="editarcliente.php?id=<?php echo $r["id"]; ?>">EDITAR</a></div></td>
                  <td width="3%"><a class="link_normal" href="editarcliente.php?id=<?php echo $r["id"]; ?>" onClick="return confirm('Tem certeza que deseja editar o cliente <?php echo $r["nome"]; ?> ?')"><img src="editar.jpg" width="24" height="24" border="0"></a></td>
                  <td width="7%"><div align="center"><a class="link_normal" href="excluicliente.php?id=<?php echo $r["id"]; ?>&amp;foto=<?php echo $r["foto"]; ?>" onClick="return confirm('Tem certeza que deseja excluir o cliente <?php echo $r["nome"]; ?> ?')">APAGAR</a></div></td>
                  <td width="3%"><div align="center"><a href="excluicliente.php?id=<?php echo $r["id"]; ?>&amp;foto=<?php echo $r["foto"]; ?>" onClick="return confirm('Tem certeza que deseja excluir o cliente <?php echo $r["nome"]; ?> ?')"><img src="lixo.gif" width="19" height="24" border="0"></a></div></td>
                  </tr>
                </table>
              </span> <span class="style2">
                <div align="center"></div>
                </span></td>
            </tr>
        </table>
        <?php }
 
  }
 
  
 ?></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
  </table>
</DIV>
<DIV class=pisos id=piso4><!-- TWITTER -->
  <DIV style="CLEAR: both"></DIV></DIV></DIV></DIV></DIV><!--fim do centro--><!--Inicio do rodape-->
<DIV style="CLEAR: both"></DIV>
<DIV id=sf_footer>
<DIV id=rodape_centro>
  <DIV class=assinatura><A class=scriptfacil title=" Casa da Web - Solu��es em Marketing Digital " 
style="FONT-SIZE: 10px; COLOR: #ffffff; TEXT-DECORATION: none" 
href="http://www.casadaweb.net" target=_blank>Desenvolvido por Casa da Web</A> 
  
</DIV></DIV></DIV><!--fim do rodape --><!-- Analytics -->
</BODY></HTML>
