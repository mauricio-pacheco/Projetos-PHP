var N_open = 0;
var I_open = 0;
var S_open = 0;
var SCRIPT_open = 0;


var tagFacil   = new Array();

var Navegador   = navigator.userAgent.toLowerCase();
var myVersion = parseInt(navigator.appVersion);

var is_ie   = ((Navegador.indexOf("msie") != -1)  && (Navegador.indexOf("opera") == -1));
var is_nav  = ((Navegador.indexOf('mozilla')!=-1) && (Navegador.indexOf('spoofer')==-1)
&& (Navegador.indexOf('compatible') == -1) && (Navegador.indexOf('opera')==-1)
&& (Navegador.indexOf('webtv') ==-1)       && (Navegador.indexOf('hotjava')==-1));

var is_win   =  ((Navegador.indexOf("win")!=-1) || (Navegador.indexOf("16bit")!=-1));
var is_mac    = (Navegador.indexOf("mac")!=-1);


// Conta o numero de tags abertas
function cstat()
{
var c = stacksize(tagFacil);

if ( (c < 1) || (c == null) ) {
c = 0;
}

if ( ! tagFacil[0] ) {
c = 0;
}
document.FORM.tagcount.value = c;
}

//--------------------------------------------
// Get stack size
//--------------------------------------------

function stacksize(thearray)
{
for (i = 0 ; i < thearray.length; i++ ) {
if ( (thearray[i] == "") || (thearray[i] == null) || (thearray == 'undefined') ) {
return i;
}
}

return thearray.length;
}

//--------------------------------------------
// Push stack
//--------------------------------------------

function pushstack(thearray, newval)
{
arraysize = stacksize(thearray);
thearray[arraysize] = newval;
}

//--------------------------------------------
// Pop stack
//--------------------------------------------

function popstack(thearray)
{
arraysize = stacksize(thearray);
theval = thearray[arraysize - 1];
delete thearray[arraysize - 1];
return theval;
}


//--------------------------------------------
// Close all tags
//--------------------------------------------

function closeall()
{
if (tagFacil[0]) {
while (tagFacil[0]) {
tagRemove = popstack(tagFacil)
document.FORM.Post.value += "[/" + tagRemove + "]";

// Change the button status
// Ensure we're not looking for FONT, SIZE or COLOR as these
// buttons don't exist, they are select lists instead.

if ( (tagRemove != 'FONT') && (tagRemove != 'SIZE') && (tagRemove != 'COLOR') )
{
eval("document.FORM." + tagRemove + ".value = ' " + tagRemove + " '");
eval(tagRemove + "_open = 0");
}
}
}

// Ensure we got them all
document.FORM.tagcount.value = 0;
tagFacil = new Array();
document.FORM.Post.focus();
}

//--------------------------------------------
// ADD CODE
//--------------------------------------------

function add_code(NewCode)
{
document.FORM.Post.value += NewCode;
document.FORM.Post.focus();
}

//--------------------------------------------
// ALTER FONT
//--------------------------------------------

function alterfont(theval, thetag)
{
if (theval == 0)
return;

if(doInsert("[" + thetag + "=" + theval + "]", "[/" + thetag + "]", true))
pushstack(tagFacil, thetag);

document.FORM.ffont.selectedIndex  = 0;
document.FORM.fsize.selectedIndex  = 0;
document.FORM.fcolor.selectedIndex = 0;

cstat();

}


//--------------------------------------------
// SIMPLE TAGS (such as B, I U, etc)
//--------------------------------------------

function simpletag(thetag) {
	var tagOpen = eval(thetag + "_open = 0");
if (tagOpen == 0) {
	if(doInsert("[" + thetag + "]", "[/" + thetag + "]", false)) {
		eval(thetag + "_open = 1");
		// Change the button status
		eval("document.FORM." + thetag + ".value += '*'");
		pushstack(tagFacil, thetag);
		cstat();
		//hstat('click_close');
	}
} else {
	// Find the last occurance of the opened tag
	lastindex = 0;
	for (i = 0 ; i < tagFacil.length; i++ ) {
		if ( tagFacil[i] == thetag ) {
			lastindex = i;
		}
	}
	// Close all tags opened up to that tag was opened
	while (tagFacil[lastindex]) {
		tagRemove = popstack(tagFacil);
		doInsert("[/" + tagRemove + "]", "", false);

		// Change the button status
		if ( (tagRemove != 'FONT') && (tagRemove != 'SIZE') && (tagRemove != 'COLOR') ) {
			eval("document.FORM." + tagRemove + ".value = ' " + tagRemove + " '");
			eval(tagRemove + "_open = 0");
		}
	}
	cstat();
}

}


function tag_list()
{
var listvalue = "init";
var thelist = "";

while ( (listvalue != "") && (listvalue != null) )
{
listvalue = prompt(list_prompt, "");
if ( (listvalue != "") && (listvalue != null) )
{
thelist = thelist+"[*]"+listvalue+"\n";
}
}

if ( thelist != "" )
{
doInsert( "[OL]\n" + thelist + "[/OL]\n", "", false);
}
}

function tag_url()
{
var FoundErrors = '';
var enterURL   = prompt(novaURL, "http://");
var enterTITLE = prompt(novaURL_name, "Por favor digite aqui um texto para apresentar o link");

if (!enterURL) {
FoundErrors += " " + error_no_url;
}
if (!enterTITLE) {
FoundErrors += " " + error_no_title;
}

if (FoundErrors) {
alert("ATEN��O! "+FoundErrors);
return;
}

doInsert("[LINK="+enterURL+"]"+enterTITLE+"[/LINK]", "", false);
}

function tag_image()
{
var FoundErrors = '';
var enterURL   = prompt(enteRimage, "http://");

if (!enterURL) {
FoundErrors += " " + error_no_url;
}

if (FoundErrors) 
{
alert("ATEN��O! "+FoundErrors);
return;
}

doInsert("[IMAGENET]"+enterURL+"[/IMAGENET]", "", false);
}

function anexos(enterURL) {

	var FoundErrors = '';

	if (!enterURL) {
		FoundErrors += " Anexo n�o encontrado";
	}
	
	if (FoundErrors) {
		alert("ATEN��O! "+FoundErrors);
		return;
	}
	if (enterURL.substr( enterURL.length -3 ) != 'zip') {
		doInsert("[IMAGEM]"+enterURL+"[/IMAGEM]", "", false);
	} else {
		var enterTITLE = prompt(novaURL_name, "Por favor digite aqui um texto para apresentar o link");
		if(enterTITLE) {
			doInsert("[LINK="+enterURL+"]"+enterTITLE+"[/LINK]", "", false);
		}
	}
}

function localImage()
{
var FoundErrors = '';
var enterURL   = prompt(enteRimageLocal, "");

if (!enterURL) {
FoundErrors += " " + error_file;
}

if (FoundErrors) 
{
alert("ATEN��O! "+FoundErrors);
return;
}

doInsert("[IMAGEM]"+enterURL+"[/IMAGEM]", "", false);
}

function tag_email()
{
var emailAddress = prompt(enteRemail, "");

if (!emailAddress) { 
alert(error_no_email); 
return; 
}

doInsert("[EMAIL="+emailAddress+"]"+emailAddress+"[/EMAIL]", "", false);
}
// fim de imagem local

// Funcao para carregar arquivos
function carga()
{
var FoundErrors = '';
var enterDOWN   = prompt(enteRdown, "");

if (!enterDOWN) {
FoundErrors += " " + error_file;
}

if (FoundErrors) 
{
alert("ATEN��O! "+FoundErrors);
return;
}

doInsert("[DOWN="+enterDOWN+"]"+enterDOWN+"[/DOWN]", "", false);
}

//Inserir email no campo de text
function tag_email()
{
var emailAddress = prompt(enteRemail, "");

if (!emailAddress) { 
alert(error_no_email); 
return; 
}

doInsert("[EMAIL="+emailAddress+"]"+emailAddress+"[/EMAIL]", "", false);
}



// Funcao que inseri o texto no campo editado
function doInsert(ibTag, ibClsTag, isSingle) {
var isClose = false;
var obj_ta = document.FORM.Post;

// Ensure it works for IE4up / Win only
if ( (myVersion >= 4) && is_ie && is_win) {
	if(obj_ta.isTextEdit){ 
		// this doesn't work for NS, but it works for IE 4+ and compatible browsers
		obj_ta.focus();
		var sel = document.selection;
		var rng = sel.createRange();
		rng.colapse;
		if((sel.type == "Text" || sel.type == "None") && rng != null){
		if(ibClsTag != "" && rng.text.length > 0)
		ibTag += rng.text + ibClsTag;
		else if(isSingle)
		isClose = true;
		
		rng.text = ibTag;
	}
	} else {
		if(isSingle) {
			isClose = true;
		}
		obj_ta.value += ibTag + ibClsTag;
	}
} else {
	if(isSingle) {
		isClose = true;
	}
	obj_ta.value += ibTag + ibClsTag;
}
obj_ta.focus();
return isClose;
}

// Textos que serao exibidos

var novaURL       		= "Por favor digite o endere�o do link";
var novaURL_name   		= "Por favor digite o texto do link";
var enteRimageLocal    	= "Por favor digite o nome da imagem. *.GIF ou *.JGP. Voc� poder� carrega-las no painel ao lado!";
var enteRimage			= "Por Favor! Digite a URL para a figura";

var enteRdown    	= "Por favor digite o nome da arquivo. Somente do Arquivo *.ZIP!";

var error_file			= "Por Favor! Digite o nome do arquivo";
var enteRemail      	= "Por Favor! Digite o email";
var error_no_url        = "Por favor! Digite uma URL";
var error_no_title      = "Por favor! Digite um titulo";
var error_no_email      = "Por favor preencha o campo e-mail";
var error_no_width      = "Voc� deve digitar uma largura";
var error_no_height     = "Voc� deve digitar uma altura";
var prompt_start        = "Digite o texto a ser formatado";
var list_prompt         = "Digite o item da lista. Clique em 'cancelar' ou deixe em branco para finalizar a lista.";