<?php require("verifica.php"); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml"><HEAD><TITLE>Lista Erechim</TITLE>
<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
<META 
content="Descri��o" 
name=description>
<META 
content="palavras, chave"><LINK media=screen href="home_arquivos/estrutura2009.css" 
type=text/css rel=stylesheet><LINK media=screen 
href="home_arquivos/interno2009.css" type=text/css rel=stylesheet><LINK 
media=screen href="home_arquivos/tooltip.css" type=text/css rel=stylesheet><LINK 
media=screen href="home_arquivos/wordcloud.css" type=text/css 
rel=stylesheet><LINK href="lupa.ico" 
rel="shortcut icon">
<LINK media=screen href="home_arquivos/MenuMatic.css" type=text/css 
charset=utf-8 rel=stylesheet><!--[if lt IE 7]>
    <link rel="stylesheet" href="home_arquivos/MenuMatic-ie6.css" type="text/css" media="screen" charset="utf-8" />
<![endif]-->
<LINK media=screen href="home_arquivos/Roar.css" type=text/css charset=utf-8 
rel=stylesheet>
<META content="MSHTML 6.00.6001.18000" name=GENERATOR></HEAD>
<BODY><!--Inicio do cabe�alho-->
<DIV id=sf_header>
<DIV id=sf_header_pai>
<DIV id=sf_header_logo><A class=logo_site 
title="Lista Erechim" 
href="index.php"></A></DIV>
<DIV id=sf_header_banner><SCRIPT src="carrega.js"></SCRIPT><SCRIPT language=javascript>
     carregaFlash('pub.swf','728','90'); // Depois s� descrever o caminho, largura, altura do SWF.
    </SCRIPT></DIV></DIV></DIV>
<DIV class=sf_header_menu>
  <table width="984" border="0" align="center">
    <tr>
      <td height="24" bordercolor="#A7D2EF" bgcolor="#C0D6E9" onClick="window.location='index.php';" onMouseOver="this.style.backgroundColor='#9ABDDC'; this.style.color='#252525'; this.style.cursor='pointer'" onMouseOut="this.style.backgroundColor='#C0D6E9'; this.style.color='#252525';" width="16%"><div align="center"><b><font color="#000000">P&aacute;gina Principal</font></b></div></td>
      <td height="24" bordercolor="#A7D2EF" bgcolor="#E6E6E6" onClick="window.location='numeros.php';" onMouseOver="this.style.backgroundColor='#9ABDDC'; this.style.color='#252525'; this.style.cursor='pointer'" onMouseOut="this.style.backgroundColor='#E6E6E6'; this.style.color='#252525';" width="16%"><div align="center"><b><font color="#000000">Cadastrar N�meros</font></b></div></td>
      <td height="24" bordercolor="#A7D2EF" bgcolor="#E6E6E6" onClick="window.location='admnumeros.php';" onMouseOver="this.style.backgroundColor='#9ABDDC'; this.style.color='#252525'; this.style.cursor='pointer'" onMouseOut="this.style.backgroundColor='#E6E6E6'; this.style.color='#252525';" width="16%"><div align="center"><b><font color="#000000">Administrar N�meros</font></b></div></td>
      <td height="24" bordercolor="#A7D2EF" bgcolor="#E6E6E6" onClick="window.location='banners.php';" onMouseOver="this.style.backgroundColor='#9ABDDC'; this.style.color='#252525'; this.style.cursor='pointer'" onMouseOut="this.style.backgroundColor='#E6E6E6'; this.style.color='#252525';" width="16%"><div align="center"><b><font color="#000000">Cadastrar Banner</font></b></div></td>
      <td height="24" bordercolor="#A7D2EF" bgcolor="#E6E6E6" onClick="window.location='admbanners.php';" onMouseOver="this.style.backgroundColor='#9ABDDC'; this.style.color='#252525'; this.style.cursor='pointer'" onMouseOut="this.style.backgroundColor='#E6E6E6'; this.style.color='#252525';" width="16%"><div align="center"><b><font color="#000000">Administrar Banners</font></b></div></td>
    </tr>
  </table>
</DIV>
<DIV id=sf_center>
<DIV id=sf_center_conteudo>
<DIV id=div_conteudo>
<DIV id=piso1>
 <table width="98%" border="0" align="center">
    <tr>
      <td><div align="center">CADASTRAR N&Uacute;MERO</div></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><script language=javascript>
function validar(cadastro) { 

if (document.cadastro.nome.value=="") {
alert("O Campo Nome n�o est� preenchido!")
cadastro.nome.focus();
return false
}

if (document.cadastro.numero1.value=="") {
alert("O Campo Telefone 1 n�o est� preenchido!")
cadastro.numero1.focus();
return false
}

if (document.cadastro.cidade.value=="") {
alert("O Campo Cidade n�o est� preenchido!")
cadastro.cidade.focus();
return false
}

if (document.cadastro.cep.value=="") {
alert("O Campo CEP n�o est� preenchido!")
cadastro.cep.focus();
return false
}

if (document.cadastro.endereco.value=="") {
alert("O Campo Endere�o n�o est� preenchido!")
cadastro.endereco.focus();
return false
}

if (document.cadastro.numero.value=="") {
alert("O Campo N�mero n�o est� preenchido!")
cadastro.numero.focus();
return false
}


}

</SCRIPT>
<script language=javascript>
function Mascara (formato, keypress, objeto){
campo = eval (objeto);

// cep
if (formato=='cep'){
separador = '-';
conjunto1 = 5;
if (campo.value.length == conjunto1){
campo.value = campo.value + separador;}
}

// telefone 1
if (formato=='numero1'){
separador1 = '(';
separador2 = ') ';
separador3 = '-';
conjunto1 = 0;
conjunto2 = 3;
conjunto3 = 9;
if (campo.value.length == conjunto1){
campo.value = campo.value + separador1;
}
if (campo.value.length == conjunto2){
campo.value = campo.value + separador2;
}
if (campo.value.length == conjunto3){
campo.value = campo.value + separador3;
}
}

// telefone 2
if (formato=='numero2'){
separador1 = '(';
separador2 = ') ';
separador3 = '-';
conjunto1 = 0;
conjunto2 = 3;
conjunto3 = 9;
if (campo.value.length == conjunto1){
campo.value = campo.value + separador1;
}
if (campo.value.length == conjunto2){
campo.value = campo.value + separador2;
}
if (campo.value.length == conjunto3){
campo.value = campo.value + separador3;
}
}


// celular 1
if (formato=='celular1'){
separador1 = '(';
separador2 = ') ';
separador3 = '-';
conjunto1 = 0;
conjunto2 = 3;
conjunto3 = 9;
if (campo.value.length == conjunto1){
campo.value = campo.value + separador1;
}
if (campo.value.length == conjunto2){
campo.value = campo.value + separador2;
}
if (campo.value.length == conjunto3){
campo.value = campo.value + separador3;
}
}

// celular 2
if (formato=='celular2'){
separador1 = '(';
separador2 = ') ';
separador3 = '-';
conjunto1 = 0;
conjunto2 = 3;
conjunto3 = 9;
if (campo.value.length == conjunto1){
campo.value = campo.value + separador1;
}
if (campo.value.length == conjunto2){
campo.value = campo.value + separador2;
}
if (campo.value.length == conjunto3){
campo.value = campo.value + separador3;
}
}


}
                    </SCRIPT>

<form name="cadastro" action="cadnumero.php" method="post" enctype="multipart/form-data" onSubmit="return validar(this)"><table width="80%" border="0" align="center">
        <tr>
          <td>* Campos Obrigat&oacute;rios</td>
        </tr>
        <tr>
          <td width="20%">Nome:
            <input name="nome" type="text" id="nome" size="90">
            *</td>
          </tr>
        <tr>
          <td>Foto: 
            <input type="file" name="foto" id="foto"></td>
        </tr>
        <tr>
          <td>Telefone 1:
            <input name="numero1" type="text" id="numero1" onKeyPress="Mascara('numero1', window.event.keyCode, 'document.cadastro.numero1');" size="30" maxlength="14" >
            *</td>
        </tr>
        <tr>
          <td>Telefone 2:
            <input name="numero2" type="text" id="numero2" onKeyPress="Mascara('numero2', window.event.keyCode, 'document.cadastro.numero2');" size="30" maxlength="14" ></td>
        </tr>
        <tr>
          <td>Celular 1:
            <input name="celular1" type="text" id="celular1" onKeyPress="Mascara('celular1', window.event.keyCode, 'document.cadastro.celular1');" size="30" maxlength="14" ></td>
        </tr>
        <tr>
          <td>Celular 2:
            <input name="celular2" type="text" id="celular2" onKeyPress="Mascara('celular2', window.event.keyCode, 'document.cadastro.celular2');" size="30" maxlength="14" ></td>
        </tr>
        <tr>
          <td>Cidade:
            <input name="cidade" type="text" id="cidade" size="50">
            * CEP: 
            <input name="cep" type="text" onKeyPress="Mascara('cep', window.event.keyCode, 'document.cadastro.cep');" id="cep" size="20" maxlength="9">
            *</td>
        </tr>
        <tr>
          <td>Estado:
            <select class="texto" 
                              name=estado>
              <option value='RS - Rio Grande do Sul' selected=selected>RS - Rio Grande do Sul</option>
              <option 
                                value='AC - Acre'>AC - Acre</option>
              <option value='AL - Alagoas'>AL - Alagoas</option>
              <option 
                                value='AM - Amazonas'>AM - Amazonas</option>
              <option value='AP - Amap&aacute;'>AP - Amap&aacute;</option>
              <option 
                                value='BA - Bahia'>BA - Bahia</option>
              <option value='CE - Cear&aacute;'>CE - Cear&aacute;</option>
              <option 
                                value='DF - Distrito Federal'>DF - Distrito Federal</option>
              <option value='ES - Esp&iacute;rito Santo'>ES - Esp&iacute;rito Santo</option>
              <option 
                                value='GO - Goi&aacute;s'>GO - Goi&aacute;s</option>
              <option value='MA - Maranh&atilde;o'>MA - Maranh&atilde;o</option>
              <option 
                                value='MG - Minas Gerais'>MG - Minas Gerais</option>
              <option value='MS - Mato Grosso do Sul'>MS - Mato Grosso do Sul</option>
              <option 
                                value='MT - Mato Grosso'>MT - Mato Grosso</option>
              <option value='PA - Par&aacute;'>PA - Par&aacute;</option>
              <option 
                                value='PB - Para&iacute;ba'>PB - Para&iacute;ba</option>
              <option value='PE - Pernambuco'>PE - Pernambuco</option>
              <option 
                                value='PI - Piau&iacute;'>PI - Piau&iacute;</option>
              <option value='PR - Paran&aacute;'>PR - Paran&aacute;</option>
              <option 
                                value='RJ - Rio de Janeiro'>RJ - Rio de Janeiro</option>
              <option value='RN - Rio Grande do Norte'>RN - Rio Grande do Norte</option>
              <option 
                                value='RO - Roraima'>RO - Roraima</option>
              <option value='RR - Roraima'>RR - Roraima</option>
              <option value='SC - Santa Catarina'>SC - Santa Catarina</option>
              <option 
                                value='SE - Sergipe'>SE - Sergipe</option>
              <option value='SP - S&atilde;o Paulo'>SP - S&atilde;o Paulo</option>
              <option 
                                value='TO - Tocantins'>TO - Tocantins</option>
            </select></td>
        </tr>
        <tr>
          <td>Endere&ccedil;o:
            <input name="endereco" type="text" id="endereco" size="70">
            *</td>
        </tr>
        <tr>
          <td>N&uacute;mero:
            <input name="numero" type="text" id="numero" size="14">
            *
            Complemento:
            <input name="complemento" type="text" id="complemento" size="30"></td>
        </tr>
        <tr>
          <td>Bairro:
            <input name="bairro" type="text" id="bairro" size="30">
            *</td>
        </tr>
        <tr>
          <td>Informa&ccedil;&otilde;es:</td>
        </tr>
        <tr>
          <td><textarea name="informacoes" id="informacoes" cols="120" rows="20"></textarea></td>
        </tr>
        <tr>
          <td><input type="submit" name="button" id="button" value="Cadastrar N�mero"></td>
          </tr>
      </table></form></td>
    </tr>
  </table>
</DIV>
<DIV class=pisos id=piso4><!-- TWITTER -->
  <DIV style="CLEAR: both"></DIV></DIV></DIV></DIV></DIV><!--fim do centro--><!--Inicio do rodape-->
<DIV style="CLEAR: both"></DIV>
<DIV id=sf_footer>
<DIV id=rodape_centro>
  <DIV class=assinatura><A class=scriptfacil title=" Casa da Web - Solu��es em Marketing Digital " 
style="FONT-SIZE: 10px; COLOR: #ffffff; TEXT-DECORATION: none" 
href="http://www.casadaweb.net" target=_blank>Desenvolvido por Casa da Web</A> 
  
</DIV></DIV></DIV><!--fim do rodape --><!-- Analytics -->
</BODY></HTML>
