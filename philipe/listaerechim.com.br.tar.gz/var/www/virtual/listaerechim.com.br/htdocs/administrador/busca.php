﻿<script language=javascript>
function validar(cadastro) { 

if (document.busca.palavra.value=="") {
alert("O Campo Pesquisar não está preenchido!")
busca.palavra.focus();
return false
}

}

</SCRIPT><form name="busca" action="pesquisar.php" method="post" onSubmit="return validar(this)"><table width="80%" border="0" align="center">
        <tr>
          <td width="10%">Pesquisar:</td>
          <td width="56%"><input name="palavra" type="text" id="palavra" size="120"></td>
          <td width="34%"><input type="submit" name="button" id="button" value="Buscar"></td>
        </tr>
      </table></form>