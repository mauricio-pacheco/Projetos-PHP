function scriptFacilTwitter(twitters){
	statusHTML = '';
	$each(twitters, function(twit){
		var username = twit.user.screen_name;
		var status = twit.text.replace(/((https?|s?ftp|ssh)\:\/\/[^"\s\<\>]*[^.,;'">\:\s\<\>\)\]\!])/g, function(url) {
			return '<a href="'+url+'" target="_blank">'+url+'</a>';
		}).replace(/\B@([_a-z0-9]+)/ig, function(reply) {
			return  reply.charAt(0)+'<a href="http://twitter.com/'+reply.substring(1)+'" target="_blank">'+reply.substring(1)+'</a>';
		});
		statusHTML += '<p><a href="http://twitter.com/'+username+'/statuses/'+twit.id+'" class="twitter2">'+relative_time(twit.created_at)+' atr�s</a> - <span class="twitter3">'+status+'</span></p>';
		
	});
	$('centro_msg_twitter').set('html',statusHTML);
}
function relative_time(time_value) {
	var values = time_value.split(" ");
	time_value = values[1] + " " + values[2] + ", " + values[5] + " " + values[3];
	var parsed_date = Date.parse(time_value);
	var relative_to = (arguments.length > 1) ? arguments[1] : new Date();
	var delta = parseInt((relative_to.getTime() - parsed_date) / 1000);
	delta = delta + (relative_to.getTimezoneOffset() * 60);
	if (delta < 60) {
		return 'menos de 1 minuto';
	} else if(delta < 120) {
		return 'mais ou menos 1 minuto';
	} else if(delta < (60*60)) {
		return (parseInt(delta / 60)).toString() + ' minutos';
	} else if(delta < (120*60)) {
		return 'cerca de 1 hora';
	} else if(delta < (24*60*60)) {
		return 'cerca ' + (parseInt(delta / 3600)).toString() + ' horas';
	} else if(delta < (48*60*60)) {
		return '1 dia ';
	} else {
		return (parseInt(delta / 86400)).toString() + ' dias';
	}
}
// JavaScript Document
window.addEvent('domready', function(){
	window.log = new Roar({
		container: $$('body')[0],
		position: 'bottomRight',
		duration: 5000
	});
	if( $('esconde_banner_dev') ){
		$('esconde_banner_dev').getElement('a').addEvent(
			'click',function(e){
				new Event(e).stop();
				$$('.chamada_dev').dissolve();
			}
		);
	}
	if($('menuuser')){
		//Menu do usu�rio logado
		new MenuMatic({id:'menuuser',subMenusContainerId:'menuuser-mmatic'});
	}else{
		//Menu de logar
		var openers = $$('.openers');
		var swithcouple = $$('div.reveal');
		openers.addEvent('click', function(ev){
			new Event(ev).stop();
			swithcouple.each(function(el){
				el[ el.getStyle('display') == 'none' ? 'reveal' : 'dissolve' ]();
			});
		});	
	}
	//Menu principal
	//scripts
	var sub_scripts = new Element('ul',{'styles':{'width':400,'overflow':'hidden'}});
	$$('.rodape_links a').each(function(lnk){
		sub_scripts.adopt( new Element('li', {'styles':{'width':200,'display':'block','float':'left'}}).adopt(lnk.clone()) );
	});
	$('mc-scripts').adopt(sub_scripts);
	//canais
	var sub_canais = new Element('ul',{'styles':{'width':360,'overflow':'hidden'}});
	$$('.rodape_links_canal a').each(function(lnk){
		sub_canais.adopt( new Element('li', {'styles':{'width':120,'display':'block','float':'left'}}).adopt(lnk.clone()) );
	});
	$('mc-colunas').adopt(sub_canais);
	new MenuMatic({id:'menu-centro',subMenusContainerId:'menu-centro-mmatic'});
	//Caixa de busca
	//texto em cima da caixa
	new OverText($('cx-busca-topo'));
	//clique na caixa
	Clientcide.setAssetLocation("/js/mootools/clientcide/Assets");
	$('cx-busca-topo').addEvent('focus', function(){
			if( this.retrieve('ptip') ){
				this.retrieve('ptip').show();
			}else{
				if( search_options ){
					opts = {point: 'up',relativeTo: this, width: 200};
					str = search_options.map(function(a){
						return '<input type="radio" name="search_place" value="{ONDE}" style="vertical-align:middle; margin-right:5px"{CHECKED} /><strong style="color:#fff">{OQUE}</strong>'.substitute({ONDE:a[0],OQUE:a[1],CHECKED:a[2]})
					}).join('<br />');
					this.store('ptip', new StickyWin.PointyTip("Onde buscar?",str, opts));
					this.retrieve('ptip').pointy.body.getElements('input').each(
						function(el){
							el.addEvents({
								'hidetip': function(){
									this.retrieve('ptip').hide();
								}.bind(this),
								'click': function(){
									this.fireEvent('hidetip',[],2000);
									$('hid-busca-topo').set('value',this.get('value'));
									//seria interessante mudar a cor da caixa de busca de acordo com a op��o de busca selecionada
								}
							})
						}.bind(this)
					)
				}
			}
		}
	);
	//Script de estrelinha
	$$('.starvote').each(
		function(el){
			(5).times(function(e){
				el.adopt(
					new Element('a',{
						'href':'javascript:void(0);',
						'title': e + 1,
						'events':{
							'mouseenter':function(){
								if( this.getParent().retrieve('votado') )
									return false;
								this.getParent().removeClass('stars' + this.getParent().get('title'));
								this.getParent().addClass('stars' + this.get('text'));
								if( !this.retrieve('avaliacoes') )
									this.store( 'avaliacoes', this.getParent().getParent().getElement('strong').get('html') );
								textos_avaliacoes = ['','Muito ruim','Tanto faz', 'Bom', 'Muito bom', 'Impressionante'];
								this.getParent().getParent().getElement('strong').set('html', textos_avaliacoes[this.get('text')])
							},
							'mouseleave':function(){
								if( this.getParent().retrieve('votado') )
									return false;
								this.getParent().removeClass('stars' + this.get('text'));
								this.getParent().addClass('stars' + this.getParent().get('title'));
								this.getParent().getParent().getElement('strong').set('html', this.retrieve('avaliacoes') )
							},
							'click':function(e){
								new Event(e).stop();
								if( this.getParent().retrieve('votado') )
									return false;
								new Request.JSON({
									url: window.location.href,
									method:'post',
									onSuccess: function(r){
										if( r.erro ){
											window.log.alert('Amigo visitante', r.msg);
										}else{
											this.getParent().set('title', this.get('title'));
											this.getParent().getParent().getElement('strong').set('html', 'Obrigado por votar' ).highlight();
											this.getParent().store('votado',true);
										}
									}.bind(this)
								}).send('acao=avaliacao&avaliacao=' + this.get('title'));
							}
						}
					}).set('html', e+1)
				);
			});
		}
	);
});
window.addEvent('load',function(){
	if( $('centro_msg_twitter') ){
		//Chama o twitter
		Asset.javascript('http://twitter.com/statuses/user_timeline/scriptfacil.json?callback=scriptFacilTwitter&count=4',{id:'twitter-js'});
	}
});