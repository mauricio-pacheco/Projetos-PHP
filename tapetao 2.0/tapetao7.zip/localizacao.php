<?php include("meta.php"); ?>
<?php include("cima.php"); ?>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="imagens/barra.png" /></td>
  </tr>
</table>
<table background="imagens/bggeral.gif" width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td valign="top"><table width="99%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><img src="imagens/branco.gif" width="2" height="6" /></td>
      </tr>
    </table>
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td><img src="imagens/faixa6.png" /></td>
        </tr>
      </table>
      <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td align="center"><iframe width="970" height="500" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com.br/maps?f=q&amp;source=s_q&amp;hl=pt-BR&amp;geocode=&amp;q=Frederico+Westphalen+Rs+Av.+S%C3%A3o+Paulo,+1079&amp;aq=&amp;sll=-27.361401,-53.402309&amp;sspn=0.016199,0.027595&amp;ie=UTF8&amp;hq=&amp;hnear=Av.+S%C3%A3o+Paulo,+1079+-+Frederico+Westphalen+-+Rio+Grande+do+Sul,+98400-000&amp;ll=-27.357623,-53.402934&amp;spn=0.032398,0.055189&amp;t=m&amp;z=14&amp;output=embed"></iframe><br /></td>
        </tr>
      </table>
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td><img src="imagens/branco.gif" width="2" height="6" /></td>
        </tr>
    </table></td>
  </tr>
</table>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="imagens/barrabaixo.png" /></td>
  </tr>
</table>
<?php include("baixo.php"); ?>
</body>
</html>