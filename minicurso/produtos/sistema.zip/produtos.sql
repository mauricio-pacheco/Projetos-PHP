CREATE TABLE `produtos` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `quantidade` varchar(50) NOT NULL,
  `marca` varchar(255) NOT NULL,
  `peso` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;