<a href="index.php">CADASTRAR PRODUTO</a><br><br>
<a href="admprodutos.php">ADMINISTRAR PRODUTOS</a><br><br>
