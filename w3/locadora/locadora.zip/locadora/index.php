<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>MV Video Locadora</TITLE>
<META http-equiv=Content-Type content="text/html; charset=windows-1252">
<STYLE type=text/css>A:link {
	COLOR: #000000; TEXT-DECORATION: none
}
A:visited {
	COLOR: #000000; TEXT-DECORATION: none
}
A:hover {
	COLOR: #365efc; TEXT-DECORATION: underline
}
#divDrag0 {
	LEFT: 0px; WIDTH: 40px; CLIP: rect(0px 120px 120px 0px); CURSOR: hand; POSITION: absolute; TOP: 0px; HEIGHT: 120px
}
</STYLE>

<META content="MSHTML 6.00.5730.13" name=GENERATOR></HEAD>
<BODY bottomMargin=0 leftMargin=0 topMargin=0 rightMargin=0>
<TABLE style="BORDER-RIGHT: #cccccc 1px solid; BORDER-LEFT: #cccccc 1px solid" 
height="100%" cellSpacing=0 cellPadding=0 width=760 align=center bgColor=#ffffff 
valign="center">
  <TBODY>
  <TR>
    <TD vAlign=top><div align="center"><BR>
          <FONT style="FONT-SIZE: 17px" face=tahoma 
      color=#003366><B>&nbsp;LOGIN NA ADMINISTRA&Ccedil;&Atilde;O DA LOCADORA</B></FONT>
    </div>
      <HR align=center width="99%" color=#cccccc SIZE=1>
      <BR></TD>
  </TR>
  <TR>
    <TD vAlign=top>
      <p align="center"><img src="mv.jpg" width="483" height="60"></p>
      <TABLE 
      style="BORDER-RIGHT: #cccccc 1px solid; BORDER-TOP: #cccccc 1px solid; BORDER-LEFT: #cccccc 1px solid; BORDER-BOTTOM: #cccccc 1px solid" 
      cellSpacing=2 cellPadding=2 align=center ?>
        <TBODY>
        <TR>
         <script language=javascript>
function validar(cadastro) { 

if (document.cadastro.usuario.value=="") {
alert("O Campo Usu�rio n�o est� preenchido!")
cadastro.usuario.focus();
return false
}

if (document.cadastro.password.value=="") {
alert("O Campo Senha n�o est� preenchido!")
cadastro.password.focus();
return false
}

		return true;

}


</SCRIPT>
    <form action="auth.php" method="post" enctype="multipart/form-data" name="cadastro" class="style24 style25 style26" onSubmit="return validar(this)">
          <TD colSpan=2><FONT style="FONT-SIZE: 11px; FONT-FAMILY: tahoma" 
            face=tahoma><B>Login no administrador</B></FONT></TD></TR>
        <TR>
          <TD colSpan=2><FONT 
            style="FONT-SIZE: 10px; COLOR: #000000; FONT-FAMILY: tahoma" 
            face=tahoma>Esta � uma �rea de acesso restrito</FONT></TD></TR>
        <TR>
          <TD><FONT style="FONT-SIZE: 11px; FONT-FAMILY: tahoma" 
            face=tahoma>Usu�rio:</FONT></TD>
          <TD><INPUT style="FONT-SIZE: 11px; FONT-FAMILY: tahoma" 
        name=usuario></TD></TR>
        <TR>
          <TD><FONT style="FONT-SIZE: 11px; FONT-FAMILY: tahoma" 
            face=tahoma>Senha:</FONT></TD>
          <TD><INPUT style="FONT-SIZE: 11px; FONT-FAMILY: tahoma" 
            type=password name=password></TD></TR>
        <TR>
          <TD></TD>
          <TD align=middle><INPUT style="FONT-SIZE: 11px; FONT-FAMILY: tahoma" type=submit value=" Entrar "> 
<INPUT style="FONT-SIZE: 11px; FONT-FAMILY: tahoma" type=reset value=Cancelar></TD></TR></FORM></TBODY></TABLE></TD></TR>
  <TR>
    <TD vAlign=bottom>
      <TABLE cellSpacing=2 cellPadding=2 width="100%" align=center 
      bgColor=#eeeeee border=0 valign="bottom">
        <TBODY>
        <TR>
          <TD vAlign=bottom align=right width="100%"><FONT style="FONT-SIZE: 11px" face=tahoma><B>� Sistema desenvolvido por 
        <A 
            style="TEXT-DECORATION: none" href="mailto:mandry@casadaweb.net" 
            target=_new>Maur�cio Pacheco</A> e  <A 
            style="TEXT-DECORATION: none" href="mailto:rossivr@hotmail.com" 
            target=_new>Vinicius Rossi</B></A></FONT></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></TABLE></BODY></HTML>
