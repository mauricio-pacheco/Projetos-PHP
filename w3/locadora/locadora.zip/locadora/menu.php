<table width="100%" border="0">
            <tr>
              <td height="20" bgcolor="#003366"><table width="100%" border="0">
                <tr>
                  <td width="7%"><img src="icon_video.gif" width="16" height="14"></td>
                  <td width="93%"><div align="left"><span class="style1">&nbsp;<strong>FILMES</strong></span></div></td>
                </tr>
              </table></td>
            </tr>
            <tr>
              <td><table height="20" width="100%" border="0">
                <tr>
                  <td width="6%"><img src="seta.gif" width="7" height="7"></td>
                  <td width="94%"><span class="style2">&nbsp;<a href="adm.php">Cadastrar Filme</a></span></td>
                </tr>
              </table></td>
            </tr>
            <tr>
              <td><table height="20" width="100%" border="0">
                <tr>
                  <td width="6%"><img src="seta.gif" width="7" height="7"></td>
                  <td width="94%"><span class="style2">&nbsp;<a href="editarfilme.php">Editar Filme</a></span></td>
                </tr>
              </table></td>
            </tr>
            <tr>
              <td><table height="20" width="100%" border="0">
                <tr>
                  <td width="6%"><img src="seta.gif" width="7" height="7"></td>
                  <td width="94%"><span class="style2">&nbsp;<a href="excluirfilme.php">Excluir Filme</a></span></td>
                </tr>
              </table></td>
            </tr>
             <tr>
              <td><table height="20" width="100%" border="0">
                <tr>
                  <td width="6%"><img src="seta.gif" width="7" height="7"></td>
                  <td width="94%"><span class="style2">&nbsp;<a href="consultarfilme.php">Consultar Filme</a></span></td>
                </tr>
              </table></td>
            </tr>

            <tr>
              <td bgcolor="#003366"><table width="100%" border="0">
                <tr>
                  <td width="7%"><img src="icon_video.gif" width="16" height="14"></td>
                  <td width="93%"><div align="left"><span class="style1">&nbsp;<strong>CLIENTES</strong></span></div></td>
                </tr>
              </table></td>
            </tr>
            <tr>
              <td><table height="20" width="100%" border="0">
                <tr>
                  <td width="6%"><img src="seta.gif" width="7" height="7"></td>
                  <td width="94%"><span class="style2">&nbsp;<a href="cadastrarcliente.php">Cadastrar Cliente</a></span></td>
                </tr>
              </table></td>
            </tr>
            <tr>
              <td><table height="20" width="100%" border="0">
                <tr>
                  <td width="6%"><img src="seta.gif" width="7" height="7"></td>
                  <td width="94%"><span class="style2">&nbsp;<a href="editarcliente.php">Editar Cliente</a></span></td>
                </tr>
              </table></td>
            </tr>
            <tr>
              <td><table height="20" width="100%" border="0">
                <tr>
                  <td width="6%"><img src="seta.gif" width="7" height="7"></td>
                  <td width="94%"><span class="style2">&nbsp;<a href="excluircliente.php">Excluir Cliente</a></span></td>
                </tr>
              </table></td>
            </tr>
             <tr>
              <td><table height="20" width="100%" border="0">
                <tr>
                  <td width="6%"><img src="seta.gif" width="7" height="7"></td>
                  <td width="94%"><span class="style2">&nbsp;<a href="consultarcliente.php">Consultar Cliente</a></span></td>
                </tr>
              </table></td>
            </tr>
            <tr>
              <td bgcolor="#003366"><table width="100%" border="0">
                <tr>
                  <td width="7%"><img src="icon_video.gif" width="16" height="14"></td>
                  <td width="93%"><div align="left"><span class="style1">&nbsp;<strong>LOCA&Ccedil;&Otilde;ES</strong></span></div></td>
                </tr>
              </table></td>
            </tr>
            <tr>
              <td><table height="20" width="100%" border="0">
                <tr>
                  <td width="6%"><img src="seta.gif" width="7" height="7"></td>
                  <td width="94%"><span class="style2">&nbsp;<a href="efetlocacao.php">Efetuar Loca&ccedil;&atilde;o</a></span></td>
                </tr>
              </table></td>
            </tr>
                        <tr>
              <td><table height="20" width="100%" border="0">
                <tr>
                  <td width="6%"><img src="seta.gif" width="7" height="7"></td>
                  <td width="94%"><span class="style2">&nbsp;<a href="exclocacao.php">Fechar Loca&ccedil;&atilde;o</a></span></td>
                </tr>
              </table></td>
            </tr>
             <tr>
              <td bgcolor="#003366"><table width="100%" border="0">
                <tr>
                  <td width="7%"><img src="icon_video.gif" width="16" height="14"></td>
                  <td width="93%"><div align="left"><span class="style1">&nbsp;<strong>EXTRAS</strong></span></div></td>
                </tr>
              </table></td>
            </tr>
            <tr>
              <td><table height="20" width="100%" border="0">
                <tr>
                  <td width="6%"><img src="seta.gif" width="7" height="7"></td>
                  <td width="94%"><span class="style2">&nbsp;<a href="locadora.doc">DOCUMENTA&Ccedil;&Atilde;O</a></span></td>
                </tr>
              </table></td>
            </tr>
            <tr>
              <td><table height="20" width="100%" border="0">
                <tr>
                  <td width="6%"><img src="seta.gif" width="7" height="7"></td>
                  <td width="94%"><span class="style2">&nbsp;<a href="locadora.zip">BAIXAR ARQUIVOS</a></span></td>
                </tr>
              </table></td>
            </tr>
          </table>