-- phpMyAdmin SQL Dump
-- version 2.7.0-pl1
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tempo de Gera��o: Nov 28, 2008 as 07:35 AM
-- Vers�o do Servidor: 5.0.32
-- Vers�o do PHP: 4.4.4-8+etch4
-- 
-- Banco de Dados: `locadora`
-- 

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `clientes`
-- 

CREATE TABLE `clientes` (
  `codigo` int(6) unsigned NOT NULL auto_increment,
  `nomecliente` varchar(250) default NULL,
  `email` varchar(150) default NULL,
  `cidade` varchar(200) default NULL,
  `estado` varchar(140) default NULL,
  `endereco` varchar(250) default NULL,
  `numero` varchar(60) default NULL,
  `bairro` varchar(150) default NULL,
  `telefone` varchar(100) default NULL,
  PRIMARY KEY  (`codigo`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Extraindo dados da tabela `clientes`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `filmes`
-- 

CREATE TABLE `filmes` (
  `codigo` int(6) unsigned NOT NULL auto_increment,
  `nomefilme` varchar(250) default '0',
  `genero` varchar(40) default '0',
  `diretor` varchar(250) default '0',
  `elenco` varchar(250) default '0',
  `preco` varchar(60) default '0',
  `sinopse` longtext,
  `estoque` varchar(60) default '0',
  `foto` varchar(255) NOT NULL,
  PRIMARY KEY  (`codigo`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

-- 
-- Extraindo dados da tabela `filmes`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `locacoes`
-- 

CREATE TABLE `locacoes` (
  `codigo` int(8) NOT NULL auto_increment,
  `codigofilme` varchar(255) NOT NULL,
  `nomefilme` varchar(255) NOT NULL,
  `nomecliente` varchar(255) NOT NULL,
  `preco` varchar(255) NOT NULL,
  `datasaida` varchar(60) NOT NULL,
  `dataentrega` varchar(60) NOT NULL,
  `status` varchar(60) NOT NULL,
  PRIMARY KEY  (`codigo`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

-- 
-- Extraindo dados da tabela `locacoes`
-- 

