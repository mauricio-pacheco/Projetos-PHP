<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /><title>ACVAN</title>
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	width:20px;
	height:4px;
	z-index:1;
	left: 469px;
	top: 421px;
}
-->
</style>
</head>
<body bgcolor="#FFFFFF" topmargin="0" leftmargin="0"><p align="left">
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000"
 codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0"
 width="500" height="462" id="CoffeeCup" align="middle">
<param name="wmode" value="Transparent"> 
<param name="movie" value="album.swf"/>
<param name="quality" value="high" />
<param name="scale" value="noscale" />
<param name="salign" value="lt" />
<param name="bgcolor" value="#ffffff" />
<embed src="album.swf" quality="high" bgcolor="#ffffff" width="500" height="462"
 name="CoffeeCup" scale="noscale" salign="lt" align="middle" type="application/x-shockwave-flash"
 pluginspage="http://www.macromedia.com/go/getflashplayer" /></object>




</p>
<div id="Layer1"><a
href="javascript:window.close()"><img src="x.gif" width="19" height="40" border="0" alt="FECHAR JANELA"></a></div>
</body></html>