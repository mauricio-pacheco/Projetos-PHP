<body style="margin:0;" topmargin="0" leftmargin="0">
<table width="890" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="631" valign="top"><link rel="stylesheet" href="banneranimado/themes/default/default.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="banneranimado/themes/pascal/pascal.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="banneranimado/themes/orman/orman.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="banneranimado/nivo-slider.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="banneranimado/style.css" type="text/css" media="screen" />
    
    
    <div id="wrapper">
      <div class="slider-wrapper theme-default">
        <div id="slider" class="nivoSlider">



     <img border="0" src="imagens/imagem1.jpg" width="620" height="226" />
     <img border="0" src="imagens/imagem2.jpg" width="620" height="226" />
     <img border="0" src="imagens/imagem3.jpg" width="620" height="226" />
     <img border="0" src="imagens/imagem4.jpg" width="620" height="226" />
     <img border="0" src="imagens/imagem5.jpg" width="620" height="226" />
     <img border="0" src="imagens/imagem7.jpg" width="620" height="226" />
     <img border="0" src="imagens/imagem6.jpg" width="620" height="226" />
      
</div>
        </div>

    </div>

<script type="text/javascript" src="banneranimado/scripts/jquery-1.6.1.min.js"></script>
    <script type="text/javascript" src="banneranimado/jquery.nivo.slider.pack.js"></script>
    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();
    });
    </script></td>
    <td width="259" valign="top"><SCRIPT src="carrega.js"></SCRIPT><SCRIPT language=javascript>
     carregaFlash("bannerlateral2.swf","166","243"); 
    </SCRIPT></td>
  </tr>
</table>
</body>